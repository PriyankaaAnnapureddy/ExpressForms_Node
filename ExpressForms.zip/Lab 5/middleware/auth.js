// we want to check if the req contains information about the user, from there we will
const authorization = (req, res, next) => {
    // this would be: localhose:#/?user=john
  const { user } = req.query;
  if (user === "john") {
    req.user = { name: "john", id: 3 };
    next();
  } else {
    res.status(401).send("Unauthorized");
  }
};

module.exports = authorization;
