const express = require("express");
const path = require("path");
const multer = require("multer");
const { body, validationResult } = require("express-validator");
const logger = require("./middleware/logger");
const authorize = require("./middleware/auth");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use([logger]);

// Configure Multer storage to use the original filename
const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "uploads/");
  },
  filename: function (req, file, callback) {
    callback(null, file.originalname); // Use the original filename
  },
});

const upload = multer({ storage: storage });

app.get("/", logger, (req, res) => {
  res.send("Home");
});

app
  .route("/register")
  .get((req, res) => {
    res.sendFile(path.join(__dirname, "views", "multi-register.html"));
  })
  .post(
    upload.single("photo"),
    [
      body("name").notEmpty().withMessage("Name is required"),
      body("username").notEmpty().withMessage("Username is required"),
      body("email").isEmail().withMessage("Enter a valid email address"),
      body("password")
        .isLength({ min: 5 })
        .withMessage("Password must be at least 5 characters long"),
    ],
    (req, res) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const user = req.body;
      console.log(user);
      console.log(req.file); // Information about the uploaded photo ID
      res.send("User registered successfully");
    }
  );

app.use((req, res, next) => {
  res.status(404).send("can't find!");
});

app.listen(8000, () => {
  console.log("Server is running on port 8000");
});
