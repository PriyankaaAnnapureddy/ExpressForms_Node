require("dotenv").config();
const express = require("express");
const app = express()
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }))
app.use(express.json());

app.get("/", (req,res)=> {
    console.log('${Date.now()}')
    console.log('${req.url}')
    console.log('${req.method}')
    res.send("HELLO")
})
app
    .route("/register")
    .get((req, res) => {res.sendFile(__dirname + "/view/register.html") })
    .post((req, res) => {res.send(req.body)});

app.listen(PORT, () => {
    console.log('http://localhost:${PORT}')
})