// https://www.npmjs.com/package/multer
// https://www.youtube.com/watch?v=i8yxx6V9UdM&ab_channel=JamesQQuick
const express = require("express");
const path = require("path");
const multer = require("multer");
const logger = require("./middleware/logger");
const authorize = require("./middleware/auth");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use([logger]);

const storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "uploads/");
  },
  filename: function (req, file, callback) {
    callback(null, file.originalname);
  },
});

const upload = multer({ storage: storage });

app.get("/", logger, (req, res) => {
  res.send("Home");
});

app
  .route("/upload")
  .get((req, res) => {
    res.sendFile(path.join(__dirname, "views", "upload.html"));
  })
  .post(upload.single("file"), (req, res) => {
    console.log(req.file); // Information about the uploaded file
    res.send("File uploaded successfully");
  });

app
  .route("/register")
  .get((req, res) => {
    res.sendFile(path.join(__dirname, "views", "register.html"));
  })
  .post((req, res) => {
    const user = req.body;
    console.log(user);
    res.send(user);
  });

app.use((req, res, next) => {
  res.status(404).send("can't find!");
});

app.listen(8000);
