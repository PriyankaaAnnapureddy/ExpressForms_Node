const express = require("express");
const path = require("path");
const logger = require("./middleware/logger");
const authorize = require("./middleware/auth");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use([logger]);

app.get("/", logger, (req, res) => {
  res.send("Home");
});

app
  .route("/register")
  .get((req, res) => {
    res.sendFile(path.join(__dirname, "views", "register.html"));
  })
  .post((req, res) => {
    const user = req.body;
    console.log(user)
    res.send(user);
  });

app.use((req, res, next) => {
  res.status(404).send("can't find!");
});

app.listen(8000);
