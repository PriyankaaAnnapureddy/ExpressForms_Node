const express = require("express");
const logger = require("./middleware/logger");
const authorize = require("./middleware/auth");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use([logger, authorize]);

app.get("/", logger, (req, res) => {
  res.send("Home");
});

app.use((req, res, next) => {
  res.status(404).send("can't find!");
});

app.listen(3000);
